#!/bin/bash
CONDA_PYTHON="/root/anaconda3/envs/torch310/bin/python"
PROJECT_DIR="/home/PycharmProjects/ultralytics-main"

export PYTHONPATH="$PROJECT_DIR"
export YOLO_OFFLINE=True
export YOLO_AUTOINSTALL=False

cd "$PROJECT_DIR" || { echo "无法切换到目录：$PROJECT_DIR"; exit 1; }

mkdir -p "$PROJECT_DIR/api_app/logs"

echo "启动违建变化检测API服务..."
nohup $CONDA_PYTHON -m api_app.app > "$PROJECT_DIR/api_app/logs/startup.log" 2>&1 &
echo "服务PID: $!"
echo "日志: $PROJECT_DIR/api_app/logs/startup.log"
echo "端口: 9030"
